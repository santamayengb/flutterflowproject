package com.flutterflow.homescreenfeed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
